-- Perfis vinculados ao auth.users do Supabase
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique,
  full_name text,
  plan text,
  favorite_genre text,
  updated_at timestamptz not null default now()
);

-- Atualiza timestamp automaticamente
create or replace function public.handle_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_profiles_updated_at on public.profiles;
-- Executa a funcao de timestamp antes de cada update no perfil.
create trigger trg_profiles_updated_at
before update on public.profiles
for each row
execute function public.handle_updated_at();

-- Cria um perfil basico quando usuario confirma cadastro
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', null))
  on conflict (id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
-- Cria o registro inicial de perfil logo apos a criacao do usuario no auth.
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;

-- Usuario autenticado pode ler apenas o proprio perfil
create policy "Can read own profile"
on public.profiles
for select
using (auth.uid() = id);

-- Usuario autenticado pode atualizar apenas o proprio perfil
create policy "Can update own profile"
on public.profiles
for update
using (auth.uid() = id)
with check (auth.uid() = id);

-- Usuario autenticado pode inserir apenas o proprio perfil
create policy "Can insert own profile"
on public.profiles
for insert
with check (auth.uid() = id);
