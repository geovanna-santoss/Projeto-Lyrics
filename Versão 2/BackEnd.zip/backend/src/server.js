import express from "express";
import cors from "cors";
import dotenv from "dotenv";

import authRoutes from "./routes/auth.routes.js";
import profileRoutes from "./routes/profile.routes.js";

// Carrega as variaveis do arquivo .env.
dotenv.config();

const app = express();
const port = process.env.PORT || 3333;

// Libera requisicoes do front-end configurado e parseia JSON automaticamente.
app.use(
  cors({
    origin: process.env.CORS_ORIGIN || "*"
  })
);
app.use(express.json());

// Endpoint simples para verificar se a API esta online.
app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "lyrics-backend" });
});

// Agrupa as rotas de autenticacao e perfil.
app.use("/auth", authRoutes);
app.use("/profile", profileRoutes);

// Handler global para erros nao tratados nas rotas.
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ message: "Erro interno do servidor." });
});

// Inicializa o servidor HTTP na porta configurada.
app.listen(port, () => {
  console.log(`API rodando em http://localhost:${port}`);
});
