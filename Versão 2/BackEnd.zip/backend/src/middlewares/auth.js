import { supabaseAdmin } from "../lib/supabase.js";

// Valida o token Bearer e injeta o usuario autenticado na requisicao.
export async function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization || "";

  if (!authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Token ausente." });
  }

  const token = authHeader.replace("Bearer ", "").trim();
  const { data, error } = await supabaseAdmin.auth.getUser(token);

  if (error || !data?.user) {
    return res.status(401).json({ message: "Token invalido ou expirado." });
  }

  req.user = data.user;
  req.accessToken = token;
  return next();
}
