import { Router } from "express";
import { supabaseAnon } from "../lib/supabase.js";

const router = Router();

// Cria uma conta no Supabase e envia os dados basicos do usuario.
router.post("/signup", async (req, res) => {
  const { email, password, fullName } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: "Email e senha sao obrigatorios." });
  }

  const { data, error } = await supabaseAnon.auth.signUp({
    email,
    password,
    options: {
      data: {
        full_name: fullName || null
      }
    }
  });

  if (error) {
    return res.status(400).json({ message: error.message });
  }

  return res.status(201).json({
    message: "Cadastro realizado. Verifique seu email para confirmar a conta.",
    user: data.user
  });
});

// Autentica o usuario e devolve a sessao para o front-end.
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: "Email e senha sao obrigatorios." });
  }

  const { data, error } = await supabaseAnon.auth.signInWithPassword({ email, password });

  if (error || !data?.session) {
    return res.status(401).json({ message: "Credenciais invalidas." });
  }

  return res.json({
    message: "Login realizado com sucesso.",
    session: {
      accessToken: data.session.access_token,
      refreshToken: data.session.refresh_token,
      expiresIn: data.session.expires_in,
      user: data.user
    }
  });
});

// Encerra a sessao local informada pelo cliente.
router.post("/logout", async (req, res) => {
  const authHeader = req.headers.authorization || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.replace("Bearer ", "").trim() : null;

  if (!token) {
    return res.status(204).send();
  }

  const { error } = await supabaseAnon.auth.signOut({ scope: "local" });

  if (error) {
    return res.status(400).json({ message: error.message });
  }

  return res.status(204).send();
});

export default router;
