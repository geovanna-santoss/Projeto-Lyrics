import { Router } from "express";
import { requireAuth } from "../middlewares/auth.js";
import { supabaseAdmin } from "../lib/supabase.js";

const router = Router();

// Retorna o perfil do usuario autenticado.
router.get("/me", requireAuth, async (req, res) => {
  const userId = req.user.id;

  const { data, error } = await supabaseAdmin
    .from("profiles")
    .select("id, full_name, email, plan, favorite_genre, updated_at")
    .eq("id", userId)
    .single();

  if (error) {
    return res.status(400).json({ message: error.message });
  }

  return res.json({ profile: data });
});

// Atualiza os campos editaveis do perfil autenticado.
router.put("/me", requireAuth, async (req, res) => {
  const userId = req.user.id;
  const { fullName, plan, favoriteGenre } = req.body;

  const updatePayload = {
    id: userId,
    email: req.user.email,
    full_name: fullName ?? null,
    plan: plan ?? null,
    favorite_genre: favoriteGenre ?? null
  };

  const { data, error } = await supabaseAdmin
    .from("profiles")
    .upsert(updatePayload, { onConflict: "id" })
    .select("id, full_name, email, plan, favorite_genre, updated_at")
    .single();

  if (error) {
    return res.status(400).json({ message: error.message });
  }

  return res.json({ message: "Perfil atualizado.", profile: data });
});

export default router;
