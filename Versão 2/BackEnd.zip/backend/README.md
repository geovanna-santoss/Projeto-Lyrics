# Backend com Supabase (JavaScript)

Esta pasta contem uma API Node.js para autenticar usuarios e gerenciar perfil usando Supabase.

## 1. Configurar Supabase

1. Crie um projeto no Supabase.
2. No SQL Editor, execute o arquivo `supabase/schema.sql`.
3. Copie as chaves em Project Settings > API.

## 2. Configurar variaveis de ambiente

1. Copie `.env.example` para `.env`.
2. Preencha:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `CORS_ORIGIN`

## 3. Instalar e rodar

```bash
cd backend
npm install
npm run dev
```

API base: `http://localhost:3333`

## 4. Rotas disponiveis

### `POST /auth/signup`
Body:
```json
{
  "email": "usuario@email.com",
  "password": "12345678",
  "fullName": "Nome Usuario"
}
```

### `POST /auth/login`
Body:
```json
{
  "email": "usuario@email.com",
  "password": "12345678"
}
```
Resposta inclui `accessToken`.

### `GET /profile/me`
Header:
`Authorization: Bearer SEU_ACCESS_TOKEN`

### `PUT /profile/me`
Header:
`Authorization: Bearer SEU_ACCESS_TOKEN`
Body:
```json
{
  "fullName": "Novo nome",
  "plan": "Premium",
  "favoriteGenre": "Pop"
}
```

## 5. Integracao no seu front atual

1. No login do `main.js`, troque a validacao local por chamada para `POST /auth/login`.
2. Salve `accessToken` em `localStorage`.
3. Ao abrir o modal de perfil, chame `GET /profile/me`.
4. Ao salvar edicao de perfil, chame `PUT /profile/me`.

Se quiser, no proximo passo eu integro isso direto no seu `main.js` atual.
